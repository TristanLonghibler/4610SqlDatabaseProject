<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con); 

$UserId = $_POST['create_id'];
$Username = $_POST['name'];
$Userage = $_POST['age'];

$sql = "INSERT INTO customer VALUES ('$Username', '$UserId', '$Userage')";

$result = mysql_query($sql);
    
header("Location: cust.php?signup=success");
	


mysql_close($con);
?>