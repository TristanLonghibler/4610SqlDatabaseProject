<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";
$mn = intval(filter_input(INPUT_GET, "mn"));
$dish = intval(filter_input(INPUT_GET, "dishid"));
$rank = intval(filter_input(INPUT_GET, "rank"));
$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con); 



$sql = "INSERT INTO reviews VALUES ('$dish', '$mn', CURRENT_TIMESTAMP, '$rank')";

$result = mysql_query($sql);
    
header("Location: reviewpage.php?mn=" . $mn . "&signup=success");
	


mysql_close($con);
?>

