<?php
$mn = intval(filter_input(INPUT_GET, "mn"));
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con);


$sql = "SHOW COLUMNS FROM table_info";
$result1 = mysql_query($sql);
while ($record = mysql_fetch_array($result1)) {
    $fields1[] = $record['0'];
}

$query = "SELECT * FROM  table_info where table_compacity <> table_Current ORDER BY table_id";
$result2 = mysql_query($query);

$data2dArr1 = array();

while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr1[$i][] = $col_value;
        $i++;
    }
}





?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>resterant: Sample</title>
		 </head>
    <body>
	<h1> Here are the tables that are avalible </h1>
	<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr1[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1); $k++) {
                        ?>
                        <td><?php print $data2dArr1[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					<td><input type="button" onclick = "join_table(<?php print $mn; ?>, <?php print $j; ?>)" value="join table"/></td>
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<script>
			
			
			function join_table(id, spot)
			{
				
				
				var passedArray = <?php echo json_encode($data2dArr1); ?>;
				var TID = passedArray[0][spot];
				document.location.href = "add_cust.php?mn=" + id + "&table=" + TID;
				
				
			}
			
			</script>
			
			
			</body>
</html>
<?php
mysql_close($con);
?>

			
			
			