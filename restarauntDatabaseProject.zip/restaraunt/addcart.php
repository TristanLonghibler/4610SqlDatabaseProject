<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";
$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$dish = intval(filter_input(INPUT_GET, "dishid"));
$con = mysql_connect($dbhost, $dbuser, $dbpassword);
$diid = strval(filter_input(INPUT_GET, "dishid"));



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con); 



$sql = "INSERT INTO contains_dishes VALUES ('$dish', '$mn')";

$result = mysql_query($sql);

$query = "UPDATE  dishes d JOIN madeof mo on d.DishID = mo.DishID JOIN Ingredients i on i.IngredientID = mo.IngredientID SET i.Quantity = i.Quantity - mo.OuncesNeeded WHERE d.DishID = " . $diid;
mysql_query($query);

    
header("Location: foodpage.php?mn=" . $mn . "&table=" . $TID . "&signup=success");
	


mysql_close($con);
?>