<?php
$mn = intval(filter_input(INPUT_GET, "mn"));
$check = intval(filter_input(INPUT_GET, "check"));
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con);


$sql = "SHOW COLUMNS FROM DISHES";
$result1 = mysql_query($sql);
while ($record = mysql_fetch_array($result1)) {
    $fields1[] = $record['0'];
}

$sql = "SHOW COLUMNS FROM Drinks";
$result2 = mysql_query($sql);
while ($record2 = mysql_fetch_array($result2)) {
    $fields2[] = $record2['0'];
}

$query = "SELECT DishID FROM  contains_dishes where cust_ID =" . $mn;
$result1 = mysql_query($query);

$data2dArr1 = array();
$data2dArr2 = array();
$data2dArr3 = array();
$data2dArr4 = array();

while ($line = mysql_fetch_array($result1, MYSQL_ASSOC)) {
    $data2dArr1[] = $line['DishID'];
}

  $query = 'SELECT * FROM  dishes where DishID IN (' . implode(',', $data2dArr1 ). ')' ;
  $result2 = mysql_query($query);
  
  
  $query = "SELECT drinkID FROM  contains_drinks where cust_ID =" . $mn;
  $result3 = mysql_query($query);
  
  
  
  
  
  
  while ($line = mysql_fetch_array($result3, MYSQL_ASSOC)) {
    $data2dArr2[] = $line['drinkID'];
}




$query = 'SELECT * FROM  drinks where drinkID IN (' . implode(',', $data2dArr2 ). ')' ;
$result4 = mysql_query($query);

while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr3[$i][] = $col_value;
        $i++;
    }
}

while ($line = mysql_fetch_array($result4, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr4[$i][] = $col_value;
        $i++;
    }
}

?>

<html>

<style>
p {
  text-align: center;
  font-size: 60px;
  margin-top: 0px;
}
</style>
    <head>
        <meta charset="UTF-8">
        <title>resterant: cart</title>
		 </head>
    <body>
	<h2> Your order should be ready in around</h2>
	<p id="demo"></p>
	<h2> minutes</h2>
	<br>
	
	<h1> Here are the menu items you selected </h1>
			<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr3[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1)-1; $k++) {
                        ?>
                        <td><?php print $data2dArr3[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					<td><img src ="<?php echo $data2dArr3[5][$j];?>" alt ="<?php print $data2dArr3[5][$j]; ?>"></td>
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<hr>
			
			<br>
			
			<h1> Here are your drinks! </h1>
			<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields2); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields2[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr4[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields2); $k++) {
                        ?>
                        <td><?php print $data2dArr4[$k][$j]; ?></td>
                        <?php
                    }
					
                    ?>
					
					
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<input type="button" onclick = "logout(<?php print $mn; ?>, <?php print $check; ?>)" value="review"/>
			
			<script>
			function add_review(id, spot)
			{
				
				
				var passedArray = <?php echo json_encode($data2dArr3); ?>;
				var did = passedArray[0][spot];
				var rank = document.getElementById(spot).value;
				document.location.href = "add_review.php?mn=" + id + "&dishid=" + did + "&rank=" + rank;
				
				
			}
			
			function logout(id, u)
			{
				document.location.href = "reviewpage.php?mn=" + id + "&check=" + u;
			}
			
			
			var countDownDate = new Date(+new Date().getTime() + 1.8e6)


var x = setInterval(function() {

  
  var now = new Date().getTime();

  
  var distance = countDownDate - now;

  

  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  
  document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "Ready";
  }
}, 1000);
			</script>
			
			</body>
</html>
<?php
mysql_close($con);
?>