<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";
$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$drink = intval(filter_input(INPUT_GET, "drinkid"));
$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con); 



$sql = "INSERT INTO contains_drinks VALUES ('$drink', '$mn')";

$result = mysql_query($sql);
$query = "UPDATE `drinks` SET `avail` = `avail` - 1 WHERE `drinkID` = " . $drink;
mysql_query($query);
    
header("Location: foodpage.php?mn=" . $mn . "&table=" . $TID . "&signup=success");
	


mysql_close($con);
?>