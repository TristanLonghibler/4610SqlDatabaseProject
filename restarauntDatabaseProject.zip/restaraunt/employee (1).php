<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";




$con = mysql_connect($dbhost, $dbuser, $dbpassword);
if (!$con) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db($dbname, $con);

$query = "SELECT serverID FROM  servers";
$result = mysql_query($query);

$data2dArr = array();

while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$data2dArr[] = $line['serverID'];
}

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Employee Login</title>
	</head>
    <body>
		<input style="width: 8em" id ="input_id" type="text" name="id" placeholder="your id" />
		<input type = "button" onclick ="empCheck()" style="width: 8em" value ="submit"/>

		<script>
			function empCheck()
			{
				var server = 0;
				var sid = 0;
				var passedArray = <?php echo json_encode($data2dArr); ?>;
				var id = document.getElementById("input_id").value;
				//console.log(id);
				//console.log("");
				for(let i = 0; i < passedArray.length; i++){
					console.log(passedArray.length);
					if(id == passedArray[i]){
						server = 1;
						sid = document.getElementById("input_id").value;
						document.location.href = "valEmp.php?mn=0&sid=" + sid;
						//console.log("Found Server");
					}
				}
				if(server == 0){
					alert("Invalid Employee ID");
				}
			}
		</script>
    </body>
</html>



<?php
mysql_close($con);
?>