<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";
$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$drink = intval(filter_input(INPUT_GET, "drinkid"));
$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

$data2dArr1 = array();
$data2dArr2 = array();


mysql_select_db($dbname, $con); 

$sql = "SHOW COLUMNS FROM ingredients";
$result1 = mysql_query($sql);
while ($record = mysql_fetch_array($result1)) {
    $fields1[] = $record['0'];
}



$sql = "SELECT IngredientID from madeofdrink where drinkID=" . $drink;
$result2 = mysql_query($sql);
while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
    $data2dArr2[] = $line['IngredientID'];
}

$query = 'SELECT * FROM  ingredients where IngredientID IN (' . implode(',', $data2dArr2 ). ')' ;
$result = mysql_query($query);

while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr1[$i][] = $col_value;
        $i++;
    }
}


    

	



?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>resterant: Sample</title>
		 </head>
    <body>
	<h1> Here are the ingrediants for this item. </h1>
<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr1[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1); $k++) {
                        ?>
                        <td><?php print $data2dArr1[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					
					
                </tr>
                <?php
            }
            ?>
			
			</table>			
			
			<input type="button" onclick = "showcart(<?php print $mn; ?>, <?php print $TID; ?>)" value="return to menu"/>
			
			<script>
			function showcart(id, TID)
			{
				document.location.href = "foodpage.php?mn=" + id + "&table=" + TID;
				
			}
			</script>
	
</body>
</html>
<?php
mysql_close($con);
?>
	