
<?php
//add things into this to allow the user see others by useing table id to grab the other users stuff, probably through a query like 

$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$check = intval(filter_input(INPUT_GET, "check"));
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db($dbname, $con);

$sql = "SHOW COLUMNS FROM DISHES";
$result1 = mysql_query($sql);
while ($record = mysql_fetch_array($result1)) {
    $fields1[] = $record['0'];
}


$query = "SELECT DishID FROM  contains_dishes where cust_ID =" . $mn;
$result2 = mysql_query($query);


$data2dArr1 = array();
$data2dArr2 = array();

while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
    $data2dArr1[] = $line['DishID'];
}

  $query = 'SELECT * FROM  dishes where DishID IN (' . implode(',', $data2dArr1 ). ')' ;
  $result3 = mysql_query($query);
  
  
  while ($line = mysql_fetch_array($result3, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr2[$i][] = $col_value;
        $i++;
    }
}



?>

<html>


    <head>
        <meta charset="UTF-8">
        <title>resterant: cart</title>
		 </head>
    <body>

<h1> Would you like to review any of these items?</h1>
			<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr2[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1)-1; $k++) {
                        ?>
                        <td><?php print $data2dArr2[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					<td><img src ="<?php echo $data2dArr2[5][$j];?>" alt ="<?php print $data2dArr3[5][$j]; ?>"></td>
					<td><input style="width: 8em" id ="<?php print $j; ?>" type="text" name="input<?php print $j; ?>" /></td>
					<td><input type="button" onclick = "add_review(<?php print $mn; ?>, <?php print $j; ?>)" value="add review"/></td>
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<input type="button" onclick = "logout(<?php print $mn; ?>)" value="log out"/>
			
			<?php if($check == 1){ ?>
			<input type="button" onclick = "pay(<?php print $mn; ?>)" value="pay"/>
			<?php 
			}
			?>
			
			
			
			<script>
			function add_review(id, spot)
			{
				
				
				var passedArray = <?php echo json_encode($data2dArr2); ?>;
				var did = passedArray[0][spot];
				var rank = document.getElementById(spot).value;
				document.location.href = "add_review.php?mn=" + id + "&dishid=" + did + "&rank=" + rank;
				
				
			}
			
			function logout(id)
			{
				document.location.href = "checkout.php?mn=" + id;
			}
			
			function pay(id)
			{
				document.location.href = "payment.php?mn=" + id;
			}
			
			</script>
			
			
			
			</body>
</html>
<?php
mysql_close($con);
?>