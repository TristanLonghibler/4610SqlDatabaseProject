<?php

$sid = strval(filter_input(INPUT_GET, "sid"));
$edit = intval(filter_input(INPUT_GET, "edit"));
$tableNum = strval(filter_input(INPUT_GET, "tableNum"));

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);
if (!$con) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db($dbname, $con);

if($edit == 1)
{
	$query = "UPDATE `ordersfrom` SET `serverID`= '$sid' WHERE table_id = '$tableNum'";
	mysql_query($query);
	$edit = 0;
}

$query = "SELECT ordersfrom.table_id FROM ordersfrom INNER JOIN table_info ON ordersfrom.table_id = table_info.table_id WHERE ordersfrom.serverID = 0 AND table_Current > 0";
$result = mysql_query($query);

$data2dArr = array();

while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$data2dArr[] = $line['table_id'];
}



?>
<html>
	
    <head>
        <meta charset="UTF-8">
        <title>Available Tables</title>
	</head>
    <body>
	<table>
		<tr>
			<td><input type = "button" onclick ="logout()" style="width: 8em" value ="logout"/></td>
			<td><input type = "button" onclick ="ctable()" style="width: 8em" value ="Current Tables"/></td>
		</tr>
		<tr>
			<td><?php print(" "); ?></td>
		</tr>
		<tr>
			<td><?php print("Available Tables"); ?></td>
		</tr>
		
	</table>
	
	
		<table>
			
			<?php
					for($j = 0; $j < count($data2dArr); $j++) {
                ?>
						<tr>
							<td><?php print $data2dArr[$j]; ?></td>
							<td><input type = "button" onclick ="addtable(<?php print $data2dArr[$j];?>)" style="width: 8em" value ="Take Table"/></td>
						</tr>
				<?php
                    }
                ?>
        </table>
		<script>
			function logout()
			{
				document.location.href = "employee.php?mn=0";
			}
			function ctable()
			{
				var sid = <?php Print($sid); ?>;
				document.location.href = "valEmptwo.php?mn=0&sid=" + sid;
			}
			function addtable(tableNum)
			{
				
				var sid = <?php Print($sid); ?>;
				console.log(sid);
				document.location.href = "valEmp.php?mn=0&sid=" + sid + "&tableNum=" + tableNum + "&edit=1";
			}
		</script>
    </body>
</html>



<?php
mysql_close($con);
?>