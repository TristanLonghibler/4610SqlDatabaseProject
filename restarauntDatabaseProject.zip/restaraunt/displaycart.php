<?php

$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con);


$sql = "SHOW COLUMNS FROM DISHES";
$result1 = mysql_query($sql);
while ($record = mysql_fetch_array($result1)) {
    $fields1[] = $record['0'];
}

$sql = "SHOW COLUMNS FROM Drinks";
$result2 = mysql_query($sql);
while ($record2 = mysql_fetch_array($result2)) {
    $fields2[] = $record2['0'];
}

$query = "SELECT DishID FROM  contains_dishes where cust_ID =" . $mn;
$result1 = mysql_query($query);

$data2dArr1 = array();
$data2dArr2 = array();
$data2dArr3 = array();
$data2dArr4 = array();

$check1 = true;
$check2 = true;
if(mysql_num_rows($result1) === 0){
	$check1 = false;
}

else{
while ($line = mysql_fetch_array($result1, MYSQL_ASSOC)) {
    $data2dArr1[] = $line['DishID'];
}

  $query = 'SELECT * FROM  dishes where DishID IN (' . implode(',', $data2dArr1 ). ')' ;
  $result2 = mysql_query($query);
  
  
  while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr3[$i][] = $col_value;
        $i++;
    }
  }}
  
  


  $query = "SELECT drinkID FROM  contains_drinks where cust_ID =" . $mn;
  $result3 = mysql_query($query);
  
  
if(mysql_num_rows($result3) === 0){
  $check2 = false;
}
  
 else
 { 
  while ($line = mysql_fetch_array($result3, MYSQL_ASSOC)) {
    $data2dArr2[] = $line['drinkID'];
}




$query = 'SELECT * FROM  drinks where drinkID IN (' . implode(',', $data2dArr2 ). ')' ;
$result4 = mysql_query($query);



while ($line = mysql_fetch_array($result4, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr4[$i][] = $col_value;
        $i++;
    }
}
}

$result7 = 0.0;
$result8 = 0.0;

if($check1 == true)
{
$query = 'select sum(Price) as price FROM dishes where DishID IN (' . implode(',', $data2dArr1 ). ')';
$result5 = mysql_query($query);

while ($line = mysql_fetch_array($result5, MYSQL_ASSOC)) {
    $result7 = $line['price'];
}
}

  
if($check2 == true){  
$query = 'select sum(price) as price FROM drinks where drinkID IN (' . implode(',', $data2dArr2 ). ')';
$result6 = mysql_query($query);
while ($line = mysql_fetch_array($result6, MYSQL_ASSOC)) {
    $result8 = $line['price'];
}
}


?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>resterant: cart</title>
		 </head>
    <body>
	<h1> Here are the menu items you selected </h1>
			<table>
			<tr>
                <?php
				echo $check1;
				if($check1 == true){
					
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr3[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1)-1; $k++) {
                        ?>
                        <td><?php print $data2dArr3[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					<td><img src ="<?php echo $data2dArr3[5][$j];?>" alt ="<?php print $data2dArr3[5][$j]; ?>"></td>
					
					
                </tr>
                <?php
				}}
				else{ ?>
					<h2> You haven't selected any food </h2>
				<?php 
				}
            ?>
			
			</table>
			
			<hr>
			
			<br>
			
			<h1> Here are our drinks! </h1>
			<table>
			<tr>
                <?php
				if($check2 == true){
                for ($i = 0; $i < count($fields2); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields2[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr4[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields2); $k++) {
                        ?>
                        <td><?php print $data2dArr4[$k][$j]; ?></td>
                        <?php
                    }
                    ?>
					
					
                </tr>
                <?php
				}}
				else{ ?>
				<h2> You havent selected a drink </h2>
				<?php 
				}
            ?>
			
			</table>
			
			<h2> Your total is  <?php print  number_format((float)$result7 + $result8, 2, '.', ''); ?> </h2>
			<input type="button" onclick = "showcart(<?php print $mn; ?>, <?php print $TID; ?>)" value="return to menu"/>
			<?php if($check1 == true || $check2 == true){ ?>
			<input type="button" onclick = "pay(<?php print $mn; ?>, <?php print $TID; ?>)" value="checkout"/>
			<?php
			}
			?>
			<script>
			function pay(id, TID)
			{
				
				document.location.href = "select_payment.php?mn=" + id + "&table=" + TID;
			}
			
			function showcart(id, TID)
			{
				document.location.href = "foodpage.php?mn=" + id + "&table=" + TID;
				
			}
			</script>
			</body>
</html>
<?php
mysql_close($con);
?>

