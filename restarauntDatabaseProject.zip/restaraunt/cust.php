<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con);


$query = "SELECT Name FROM  customer";
$result = mysql_query($query);

$query = "SELECT cust_ID FROM  customer";
$result2 = mysql_query($query);

$data2dArr1 = array();
$data2dArr2 = array();

while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
    $data2dArr1[] = $line['Name'];
}

while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
    
	$data2dArr2[] = $line['cust_ID'];
}

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>cust: Sample</title>
		 </head>
    <body>
	
	
	
	<h1> Please enter your name and id here </h1>
	<input style="width: 8em" id ="input_name" type="text" name="name" placeholder="your name" />

	<input style="width: 8em" id ="input_id" type="text" name="id" placeholder="your id" />

	<input type = "button" onclick ="check_query()" style="width: 8em" value ="submit"/>
	
	<h1> To create a new account, enter the requested information below <h1>
	<form action="create.php" method ="post" name="add">

    <input style="width: 8em" id ="create name" type="text" name="name" placeholder="your name" />
	
    <br>
	<input style="width: 8em" id ="create_ID" type="text" name="create_id" placeholder="your ID" />
	<br>
	<input style="width: 8em" id ="add_age" type="text" name="age" placeholder="your age" />
	<br>
	
    <input type="submit" value="Submit">

	</form>


	   <script>
	   
			function check_query()
			{
				
				var passedArray = <?php echo json_encode($data2dArr1); ?>;
				var passedArray2 = <?php echo json_encode($data2dArr2); ?>;
				var x = document.getElementById("input_name").value;
				var e2 = document.getElementById("input_id").value;
				var check1 = false;
				var check2 = false;
				
				
				
				for(var i = 0; i < passedArray.length; i++)
				{
					
					
					if(x == passedArray[i])
					{
						
						
						check1 = true;
					
						if (check1 == true)
						{
							
							if(e2 == passedArray2[i])
							{
								
								document.location.href = "table_select.php?mn=" + e2;
								check2 = true;
							}
						}
						
						else
						{
							check1 = false;
						}
						
						
						
						
					}
					
					
					
				}
				if(check2 == false)
				{
					alert("Sorry, that acount does not exist, please try again or input in a name, id, and age down below.");
				}
				
				
				
				
			}
	   
	   </script>
    </body>
</html>



<?php
mysql_close($con);
?>