<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";
$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$dish = intval(filter_input(INPUT_GET, "dishid"));
$rank = intval(filter_input(INPUT_GET, "rank"));
$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con); 



$sql = "INSERT INTO table_num VALUES ('$TID', '$mn')";

$result = mysql_query($sql);

$sql2 = "update table_info set table_Current = table_Current + 1 where table_id =".$TID;
$result2 = mysql_query($sql2);
    
header("Location: foodpage.php?mn=" . $mn . "&table=" . $TID);
	


mysql_close($con);
?>