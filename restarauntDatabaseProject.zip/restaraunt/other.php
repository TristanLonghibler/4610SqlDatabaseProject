<?php
//add things into this to allow the user see others by useing table id to grab the other users stuff, probably through a query like 

$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

$checkpay = 1;

$data2dArr6 = array();
$data2dArr7 = array();
$data2dArr8 = array();
$data2dArr9 = array();
$data2dArr10 = array();
$data2dArr11 = array();
$data2dArr12 = array();

mysql_select_db($dbname, $con);
$check1 = true;
$check2 = true;
$check3 = true;


$sql1 = "SELECT cust_ID from table_num where table_id =" . $TID;
$result10 = mysql_query($sql1);


	

while ($line = mysql_fetch_array($result10, MYSQL_ASSOC)) {
    $data2dArr6[] = $line['cust_ID'];
}


$sql = 'SELECT DishID from contains_dishes where cust_ID in (' . implode(',', $data2dArr6 ). ') and cust_ID <>' . $mn;
$result11 = mysql_query($sql);

if(mysql_num_rows($result11) === 0)
{
$check1 = false;
}
else{
while ($line = mysql_fetch_array($result11, MYSQL_ASSOC)) {
    $data2dArr7[] = $line['DishID'];
}

$sql1 = 'SELECT * FROM  dishes where DishID IN (' . implode(',', $data2dArr7 ). ')' ;
  $result12 = mysql_query($sql1);


while ($line = mysql_fetch_array($result12, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr8[$i][] = $col_value;
        $i++;
    }
}}



$sql = 'SELECT drinkID from contains_drinks where cust_ID in (' . implode(',', $data2dArr6 ). ')and cust_ID <>' . $mn;
$result13 = mysql_query($sql);
if(mysql_num_rows($result13) === 0)
{
	$check2 = false;
	
}
else{
while ($line = mysql_fetch_array($result13, MYSQL_ASSOC)) {
    $data2dArr9[] = $line['drinkID'];
}

$sql = 'SELECT * FROM  drinks where drinkID IN (' . implode(',', $data2dArr9 ). ')' ;
  $result14 = mysql_query($sql);


while ($line = mysql_fetch_array($result14, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr10[$i][] = $col_value;
        $i++;
    }
}
}

$result17 = 0.0;
$result18 = 0.0;


if($check1 == true){
$sql = 'SELECT sum(Price) as price from dishes where DishID in (' . implode(',', $data2dArr7 ). ')';
$result15 = mysql_query($sql);
while ($line = mysql_fetch_array($result15, MYSQL_ASSOC)) {
    $result17 = $line['price'];
}}



if($check2 == true){
$sql = 'SELECT sum(price) as price from drinks where drinkID in (' . implode(',', $data2dArr9 ). ')';
$result16 = mysql_query($sql);



while ($line = mysql_fetch_array($result16, MYSQL_ASSOC)) {
    $result18 = $line['price'];
}
}







$sql = "SHOW COLUMNS FROM DISHES";
$result1 = mysql_query($sql);
while ($record = mysql_fetch_array($result1)) {
    $fields1[] = $record['0'];
}

$sql = "SHOW COLUMNS FROM Drinks";
$result2 = mysql_query($sql);
while ($record2 = mysql_fetch_array($result2)) {
    $fields2[] = $record2['0'];
}

$query = "SELECT DishID FROM  contains_dishes where cust_ID =" . $mn;
$result1 = mysql_query($query);

$data2dArr1 = array();
$data2dArr2 = array();
$data2dArr3 = array();
$data2dArr4 = array();

while ($line = mysql_fetch_array($result1, MYSQL_ASSOC)) {
    $data2dArr1[] = $line['DishID'];
}

  $query = 'SELECT * FROM  dishes where DishID IN (' . implode(',', $data2dArr1 ). ')' ;
  $result2 = mysql_query($query);
  
  
  $query = "SELECT drinkID FROM  contains_drinks where cust_ID =" . $mn;
  $result3 = mysql_query($query);
  
  
  
  
  
  
  while ($line = mysql_fetch_array($result3, MYSQL_ASSOC)) {
    $data2dArr2[] = $line['drinkID'];
}




$query = 'SELECT * FROM  drinks where drinkID IN (' . implode(',', $data2dArr2 ). ')' ;
$result4 = mysql_query($query);

while ($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr3[$i][] = $col_value;
        $i++;
    }
}

while ($line = mysql_fetch_array($result4, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr4[$i][] = $col_value;
        $i++;
    }
}

$sql = 'SELECT sum(Price) as price from dishes where DishID in (' . implode(',', $data2dArr1 ). ')';
$result19 = mysql_query($sql);



$sql = 'SELECT sum(price) as price from drinks where drinkID in (' . implode(',', $data2dArr2 ). ')';
$result20 = mysql_query($sql);


while ($line = mysql_fetch_array($result19, MYSQL_ASSOC)) {
    $result21 = $line['price'];
}
while ($line = mysql_fetch_array($result20, MYSQL_ASSOC)) {
    $result22 = $line['price'];
}

?>

<html>

<style>
p {
  text-align: center;
  font-size: 60px;
  margin-top: 0px;
}
</style>
    <head>
        <meta charset="UTF-8">
        <title>resterant: cart</title>
		 </head>
    <body>
	<h2> Your order should be ready in around</h2>
	<p id="demo"></p>
	<h2> minutes</h2>
	<br>
	
	<h2> Here is what the others at your table ordered </h2>
	<table>
			<tr>
                <?php
				if($check1 == true){
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr8[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1)-1; $k++) {
                        ?>
                        <td><?php print $data2dArr8[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					<td><img src ="<?php echo $data2dArr8[5][$j];?>" alt ="<?php print $data2dArr8[5][$j]; ?>"></td>
                </tr>
                <?php
				}}
            else{ ?>
					<h2> Your table hasn't selected any food </h2>
				<?php 
				}
            ?>
			
			</table>
			
	<h2> here are the drinks ordered by the others at the table <h2>
	
	<table>
			<tr>
                <?php
				if($check2 == true){
                for ($i = 0; $i < count($fields2); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields2[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr10[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields2); $k++) {
                        ?>
                        <td><?php print $data2dArr10[$k][$j]; ?></td>
                        <?php
                    }
					
                    ?>
					
					
					
                </tr>
                <?php
				}}
            else{ ?>
					<h2> You table hasn't selected any drinks </h2>
				<?php 
				}
            ?>
			
			</table>
	
	
	
	
	
	
	<h1> Here are the menu items you selected </h1>
			<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr3[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1)-1; $k++) {
                        ?>
                        <td><?php print $data2dArr3[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					<td><img src ="<?php echo $data2dArr3[5][$j];?>" alt ="<?php print $data2dArr3[5][$j]; ?>"></td>
					
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<hr>
			
			<br>
			
			<h1> Here are our drinks! </h1>
			<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields2); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields2[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr4[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields2); $k++) {
                        ?>
                        <td><?php print $data2dArr4[$k][$j]; ?></td>
                        <?php
                    }
					
                    ?>
					
					
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<h2> the total price is <?php print  number_format((float)$result17 + $result18 + $result22 + $result21, 2, '.', ''); ?> </h2>
			
			<input type="button" onclick = "logout(<?php print $mn; ?>, <?php print $checkpay; ?>)" value="reviews"/>
			
			<script>
			
			
			function logout(id, u)
			{
				document.location.href = "reviewpage.php?mn=" + id + "&check=" + u;
			}
			
			
			
			
			
			

var countDownDate = new Date(+new Date().getTime() + 1.8e6)


var x = setInterval(function() {

  
  var now = new Date().getTime();

  
  var distance = countDownDate - now;

  

  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  
  document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "Ready";
  }
}, 1000);
			</script>
			
			</body>
</html>
<?php
mysql_close($con);
?>