<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";
$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
?>

<html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>resterant: Sample</title>
		 </head>
    <body>
	
	<h1> Are you paying for your own meal, someone else at the table paying, or are you playing for the table? </h1>
	
	<input type="button" onclick = "own(<?php print $mn; ?>, <?php print $TID; ?> , <?php print 1; ?>)" value="paying for myself"/>
	<input type="button" onclick = "other(<?php print $mn; ?>, <?php print $TID; ?>)" value="other"/>
	<input type="button" onclick = "other_2(<?php print $mn; ?>, <?php print $TID; ?>)" value="someone else"/>
	
	<script>
	function own(id, TID, u)
	{
		document.location.href = "order.php?mn=" + id + "&check=" + u;
				
	}
	function other(id, TID)
	{
		document.location.href = "other.php?mn=" + id + "&table=" + TID;
				
	}
	function other_2(id, TID)
	{
		document.location.href = "order.php?mn=" + id ;
				
	}
	
	
	
	</script>
	</body>
</html>
