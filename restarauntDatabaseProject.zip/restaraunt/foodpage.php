<?php

//the first result grabs the columns from the selected table.
//the second result grabs the columns from the dishes table
//the third results grabs the rows from the dishes table ** modify this to grab them in groups
//the fourth result grabs the rows from the drinks table ** modify this to grab them in groups

$mn = intval(filter_input(INPUT_GET, "mn"));
$TID = intval(filter_input(INPUT_GET, "table"));
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con);

$lastheader = "Times Reviewed";
$data2dArr20 = array();
$data2dArr21 = array();
$data2dArr22 = array();
$check = true;
//$query = "SELECT d.DishID, d.DName, d.DCalories, d.Price, d.Popularity, d.Image, count(r.DishID) as times FROM  reviews as r, dishes as d where r.cust_ID =" . $mn . " and d.DishID = r.DishID group by d.DishID, d.DName, d.DCalories, d.Price, d.Popularity, d.Image order by count(r.DishID) limit 3";
$query = "SELECT DishID FROM  reviews where cust_ID =" . $mn;
$result20 = mysql_query($query);

while ($line = mysql_fetch_array($result20, MYSQL_ASSOC)) {
    $data2dArr20[] = $line['DishID'];
}

$query = 'SELECT * FROM  dishes where DishID IN (' . implode(',', $data2dArr20 ). ')' ;
$result21 = mysql_query($query);

if($result21 == false)
{
	$data2dArr21[] = "You havent reviewed anything, when you do, your most reviewed items will show up here";
	$check = false;
}
else{
while ($line = mysql_fetch_array($result21, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr21[$i][] = $col_value;
        $i++;
    }
}
}


$query = "SELECT DishID, count(DishID) as count FROM  reviews where cust_ID =" . $mn . " group by DishID order by count(DishID) desc limit 3";
$result22 = mysql_query($query);
if($result22 == false)
{
	$data2dArr22[] = "N/A";
}
else{
while ($line = mysql_fetch_array($result22, MYSQL_ASSOC)) {
    $data2dArr22[] = $line['count'];
}
}



$sql = "SHOW COLUMNS FROM DISHES";
$result1 = mysql_query($sql);
while ($record = mysql_fetch_array($result1)) {
    $fields1[] = $record['0'];
}

$sql = "SHOW COLUMNS FROM Drinks";
$result2 = mysql_query($sql);
while ($record2 = mysql_fetch_array($result2)) {
    $fields2[] = $record2['0'];
}

$query = "SELECT * FROM  DISHES ORDER BY Popularity desc";
$result3 = mysql_query($query);

$query = "SELECT * FROM  drinks ORDER BY drinkID";
$result4 = mysql_query($query);

$data2dArr1 = array();
$data2dArr2 = array();
$data2dArr3 = array();
$data2dArr4 = array();

while ($line = mysql_fetch_array($result3, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr1[$i][] = $col_value;
        $i++;
    }
}

while ($line = mysql_fetch_array($result4, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr2[$i][] = $col_value;
        $i++;
    }
}

$sql = "SHOW COLUMNS FROM DISHES";
$result5 = mysql_query($sql);
while ($record3 = mysql_fetch_array($result5)) {
    $fields3[] = $record3['0'];
}

$query = "SELECT * FROM  DISHES order by popularity desc limit 3" ;
$result6 = mysql_query($query);

while ($line = mysql_fetch_array($result6, MYSQL_ASSOC)) {
    $i = 0;
    foreach ($line as $col_value) {
        $data2dArr3[$i][] = $col_value;
        $i++;
    }
}
?>


<html>
    <head>
        <meta charset="UTF-8">
        <title>resterant: Sample</title>
		 </head>
    <body>
	<h1> Here are the three most popular items you have had before </h1>
        <table>
			<tr>
                <?php
				if($check == true){
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
				<th style="width: 7em"><?php print $lastheader; ?></th>
				<?php
				}
				?>
            </tr>
			
			<?php
			if($check == true){
            for ($j = 0; $j < count($data2dArr21[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1) - 1; $k++) {
                        ?>
                        <td><?php echo $data2dArr21[$k][$j]; ?></td>
						
                        <?php
						
                    }
                    ?>
					<td><img src ="<?php print $data2dArr21[5][$j];?>" alt ="<?php print $data2dArr21[5][$j]; ?>"></td>
					<td> <?php echo $data2dArr22[$j]; ?></td>
					<td><input type="button" onclick = "add_dish(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="add to cart"/></td>
					<td><input type="button" onclick = "show_i_1(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="show ingredients"/></td>
					
                </tr>
                <?php
            }}
			else{?>
			<h2> Sorry, you have not reviewed anything, once you do, they will start showing up here</h2>
				
			<?php
			}
            ?>
			
			</table>
			<hr>
			<br>
	
	
	<h1> Here are the three most popular items </h1>
        <table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields3); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields3[$i]; ?></th>
                    <?php
                }
                ?>
				
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr3[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields3) - 1; $k++) {
                        ?>
                        <td><?php echo $data2dArr3[$k][$j]; ?></td>
						
                        <?php
						
                    }
                    ?>
					<td><img src ="<?php print $data2dArr3[5][$j];?>" alt ="<?php print $data2dArr3[5][$j]; ?>"></td>
					<td><input type="button" onclick = "add_dish_2(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="add to cart"/></td>
					<td><input type="button" onclick = "show_i_2(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="show ingredients"/></td>
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			<hr>
			<br>
			
			<h1> Here are our menu items </h1>
			<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields1); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields1[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr1[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields1)-1; $k++) {
                        ?>
                        <td><?php print $data2dArr1[$k][$j]; ?></td>
						
                        <?php
                    }
                    ?>
					<td><img src ="<?php echo $data2dArr1[5][$j];?>" alt ="<?php print $data2dArr1[5][$j]; ?>"></td>
					<td><input type="button" onclick = "add_dish_1(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="add to cart"/></td>
					<td><input type="button" onclick = "show_i_3(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="show ingredients"/></td>
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<hr>
			
			<br>
			
			<h1> Here are our drinks! </h1>
			<table>
			<tr>
                <?php
                for ($i = 0; $i < count($fields2); $i++) {
                    ?>
                    <th style="width: 7em"><?php print $fields2[$i]; ?></th>
                    <?php
                }
                ?>
            </tr>
			
			<?php
            for ($j = 0; $j < count($data2dArr2[0]); $j++) {
                ?>
                <tr>
                    <?php
                    for ($k = 0; $k < count($fields2); $k++) {
                        ?>
                        <td><?php print $data2dArr2[$k][$j]; ?></td>
                        <?php
                    }
                    ?>
					<td><input type="button" onclick = "add_drink(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="add to cart"/></td>
					<td><input type="button" onclick = "show_i_4(<?php print $mn; ?>, <?php print $j; ?>, <?php print $TID; ?>)" value="show ingredients"/></td>
					
                </tr>
                <?php
            }
            ?>
			
			</table>
			
			<input type="button" onclick = "showcart(<?php print $mn; ?>, <?php print $TID; ?>)" value="Check out"/>
			
			<script>
			function add_dish(id, spot, TID)
			{
				
				
				var passedArray = <?php echo json_encode($data2dArr21); ?>;
				var did = passedArray[0][spot];
				document.location.href = "addcart.php?mn=" + id + "&dishid=" + did + "&table=" + TID;
				
				
			}
			
			function add_dish_1(id, spot, TID)
			{
				
				
				var passedArray = <?php echo json_encode($data2dArr1); ?>;
				var did = passedArray[0][spot];
				document.location.href = "addcart.php?mn=" + id + "&dishid=" + did + "&table=" + TID;
				
				
			}
			
			function add_dish_2(id, spot, TID)
			{
				
				
				var passedArray = <?php echo json_encode($data2dArr3); ?>;
				var did = passedArray[0][spot];
				document.location.href = "addcart.php?mn=" + id + "&dishid=" + did + "&table=" + TID;
				
				
			}
			function add_drink(id, spot, TID)
			{
				var passedArray = <?php echo json_encode($data2dArr2); ?>;
				var did = passedArray[0][spot];
				//console.log(did);
				document.location.href = "adddrink.php?mn=" + id + "&drinkid=" + did +"&table=" + TID;
			}
			function show_i_1(id, spot, TID)
			{
				var passedArray = <?php echo json_encode($data2dArr21); ?>;
				var did = passedArray[0][spot];
				document.location.href = "showingi.php?mn=" + id + "&dishid=" + did +"&table=" + TID;
			}
			function show_i_2(id, spot, TID)
			{
				var passedArray = <?php echo json_encode($data2dArr3); ?>;
				var did = passedArray[0][spot];
				document.location.href = "showingi.php?mn=" + id + "&dishid=" + did +"&table=" + TID;
			}
			function show_i_3(id, spot, TID)
			{
				var passedArray = <?php echo json_encode($data2dArr1); ?>;
				var did = passedArray[0][spot];
				document.location.href = "showingi.php?mn=" + id + "&dishid=" + did +"&table=" + TID;
			}
			function show_i_4(id, spot, TID)
			{
				var passedArray = <?php echo json_encode($data2dArr2); ?>;
				var did = passedArray[0][spot];
				document.location.href = "showingii.php?mn=" + id + "&drinkid=" + did +"&table=" + TID;
			}
			
			function showcart(id, TID)
			{
				document.location.href = "displaycart.php?mn=" + id + "&table=" + TID;
				
			}
			
			
			
			</script>
			
			
			
		
		
		
            
    </body>
</html>
<?php
mysql_close($con);
?>














