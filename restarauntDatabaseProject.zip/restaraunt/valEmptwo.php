<?php

$sid = strval(filter_input(INPUT_GET, "sid"));
$edit = intval(filter_input(INPUT_GET, "edit"));
$tableNum = strval(filter_input(INPUT_GET, "tableNum"));

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);
if (!$con) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db($dbname, $con);

if($edit == 1)
{
	$query = "UPDATE `ordersfrom` SET `serverID`= 0 WHERE table_id = '$tableNum'";
	mysql_query($query);
	$query = "UPDATE `table_info` SET `table_Current`= 0 WHERE table_id = '$tableNum'";
	mysql_query($query);
	$query = "delete from table_num WHERE table_id = '$tableNum'";
	mysql_query($query);
	$edit = 0;
}

$query = "SELECT table_id FROM ordersfrom WHERE serverID = " . $sid;
$result = mysql_query($query);

$data2dArr = array();

while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$data2dArr[] = $line['table_id'];
}



?>
<html>
	
    <head>
        <meta charset="UTF-8">
        <title>Current Tables</title>
	</head>
    <body>
	<table>
		<tr>
			<td><input type = "button" onclick ="logout()" style="width: 8em" value ="logout"/></td>
			<td><input type = "button" onclick ="ctable()" style="width: 8em" value ="Available Tables"/></td>
		</tr>
		<tr>
			<td><?php print(" "); ?></td>
		</tr>
		<tr>
			<td><?php print("Current Tables"); ?></td>
		</tr>
		
	</table>
	
	
		<table>
			
			<?php
					for($j = 0; $j < count($data2dArr); $j++) {
                ?>
						<tr>
							<td><?php print $data2dArr[$j]; ?></td>
							<td><input type = "button" onclick ="donetable(<?php print $data2dArr[$j];?>)" style="width: 8em" value ="Finished"/></td>
						</tr>
				<?php
                    }
                ?>
        </table>
		<script>
			function logout()
			{
				document.location.href = "employee.php?mn=0";
			}
			function ctable()
			{
				var sid = <?php Print($sid); ?>;
				document.location.href = "valEmp.php?mn=0&sid=" + sid;
			}
			function donetable(tableNum)
			{
				
				var sid = <?php Print($sid); ?>;
				console.log(sid);
				document.location.href = "valEmptwo.php?mn=0&sid=" + sid + "&tableNum=" + tableNum + "&edit=1";
			}
		</script>
    </body>
</html>



<?php
mysql_close($con);
?>