<?php
//add things into this to allow the user see others by useing table id to grab the other users stuff, probably through a query like 

$mn = intval(filter_input(INPUT_GET, "mn"));
?>
<html>


    <head>
        <meta charset="UTF-8">
        <title>resterant: cart</title>
		 </head>
    <body>

<h1> Please enter your card information</h1>
<td><input style="width: 8em" id ="cardnum " type="text" name="cnum ?>" /></td>
<br>
<td><input style="width: 8em" id ="date" type="text" name="datenum" /></td>
<br>
<td><input style="width: 8em" id ="securnum" type="text" name="back_nums" /></td>
<br>

<td><input type="button" onclick = "logout(<?php print $mn;?>)" value="log out"/></td>

<Script>
			function logout(id)
			{
				document.location.href = "checkout.php?mn=" + id;
			}

</script>

</body>
</html>