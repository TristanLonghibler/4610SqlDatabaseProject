<?php
$mn = intval(filter_input(INPUT_GET, "mn"));
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "restaraunt";

$con = mysql_connect($dbhost, $dbuser, $dbpassword);



if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db($dbname, $con);


$query = "DELETE FROM contains_dishes where cust_ID =" . $mn;
$result1 = mysql_query($query);
$query = "DELETE FROM contains_drinks where cust_ID =" . $mn;
$result3 = mysql_query($query);




    
header("Location: cust.php");
	


mysql_close($con);
?>